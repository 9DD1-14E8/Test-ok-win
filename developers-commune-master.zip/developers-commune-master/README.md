# developers-commune
Web application created using React, Express and MongoDB which allows users to create their profile by adding bio | past and current education and experience | social media account links . They can then add posts | view others' profile and posts | add likes and comments .  
# How to run the app
Download/Clone the source code of project
Open two two terminals . One for front and other for backend .
In one of the terminal - Run npm install - npm start
In other terminal - cd client - npm install - npm start
Your are good to go .
